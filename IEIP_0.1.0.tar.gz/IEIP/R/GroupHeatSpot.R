#' @title plotgene
#' @name plotgene
#' @description The function is used to plot the gene structure.
#'
#'
#' @param region A gene region that is the GRanges.
#' @param geneModul A TxDb object made from GTF used by BAM aligner or a GRangesList object.
#' @param shrinkage the shrinkage for intron region (must be a positive >= 1). default 1 for no shrinkage.
#' @param reduce To collapse all gene structure annotation features or not.
#' @param returnData logical value, indicating return data or plot.
#' @param removeTxid logical value, indicating whether to remove the transcript of y axis lab.
#' 
#'
#' @importFrom ggbio autoplot
#' @importFrom ggbio theme_null
#' @import ggplot2
#' 
#'

plotgene <- function(region,
                     geneModul,
                     shrinkage = 1,
                     reduce = FALSE,
                     returnData = FALSE,
                     removeTxid = FALSE
                     ) {
  
  if(!(is(geneModul, "TxDb") | is(geneModul, "GRangesList"))) {
    stop("geneModul must be a TxDb form GenomicFeatures or a GRangesList")
  }
  
  if(shrinkage < 1) {
    stop("shrinkage must be >= 1")
  }
  
  if(!is.logical(reduce)) {
    stop("reduce must be logical value")
  }
  
  if(!is.logical(returnData)) {
    stop("returnData must be a logical value")
  }
  
  if(!is.logical(removeTxid)) {
    stop("removeTxid must be a logical value")
  }
  
  
  
  if(shrinkage == 1) { # original size
    if(is(geneModul, "TxDb")) { # From TxDb
      if(reduce) {
        p4 <- tryCatch(ggbio::autoplot(geneModul, which = region, stat = "reduce"), error = function(e) stop("maybe your TxDb external pointer is not valid"))
      } else {
        p4 <- tryCatch(ggbio::autoplot(geneModul, which = region, loadings.label.vjust = 1.2), error = function(e) stop("maybe your TxDb external pointer is not valid"))
      }
      
      p4 <- p4 + theme_null()
      p4 <- p4@ggplot
      
      ypos <- lapply(ggplot_build(p4)$data, function(x) suppressWarnings(max(x$y)))
      ypos <- max(unlist(ypos[!mapply(is.infinite, ypos)]))
      
      plast <- p4 + 
        lims(y = c(0, ypos * 1.2)) +
        scale_x_continuous(expand = c(0, 0))
      
      
    }
  }
  
  if(removeTxid) {
    plast <- plast + theme(axis.text.y = element_blank())
  }
  
  if(returnData) {
    res <- tryCatch(list(plast, ex_base_tab_sub), error = function(e) plast)
  } else {
    res <- plast
  }
  return(res)
}




#' @title ReadBam
#' @importFrom Rsamtools scanBamFlag
#' @importFrom Rsamtools ScanBamParam
#' @importFrom GenomicRanges reduce
#' @importFrom BiocGenerics start
#' @importFrom BiocGenerics end
#' @importFrom Rsamtools BamFile
#' @importFrom GenomicAlignments readGAlignments
#' @importFrom GenomeInfoDb seqlevels
#' @importFrom GenomicAlignments coverage
#' @importFrom GenomicAlignments strand
#' @importFrom BiocGenerics start end
#' 
#' 
#' 

ReadBam <- function(BamFile, region, ignore.strand = T, singleEnd = F, antisense = T, strandMode = 2, mapqFilter = 0) {
  flag <- Rsamtools::scanBamFlag(isSecondaryAlignment = FALSE, isNotPassingQualityControls = FALSE, isUnmappedQuery = FALSE)
  sbp <- Rsamtools::ScanBamParam(flag = flag, mapqFilter = mapqFilter, which = region)
  
  if(ignore.strand) {
    if(singleEnd) {
      galp0 <- GenomicAlignments::readGAlignments(Rsamtools::BamFile(BamFile), use.names = FALSE, param = sbp)
    } else {
      galp0 <- GenomicAlignments::readGAlignmentPairs(Rsamtools::BamFile(BamFile), use.names = FALSE, param = sbp)
    }
  } else {
    if(singleEnd) {
      if(antisense) {
        galp0 <- GenomicAlignments::readGAlignments(Rsamtools::BamFile(BamFile), use.names = FALSE, param = sbp)
        GenomicAlignments::strand(galp0) <- ifelse(GenomicAlignments::strand(galp0) == "*", "*", ifelse(GenomicAlignments::strand(galp0) == "+", "-", "+"))
      } else {
        galp0 <- GenomicAlignments::readGAlignments(Rsamtools::BamFile(BamFile), use.names = FALSE, param = sbp)
      }
    } else {
      galp0 <- GenomicAlignments::readGAlignmentPairs(Rsamtools::BamFile(BamFile), use.names = FALSE, param = sbp, strandMode = strandMode)
    }
  }
  
  galp0 <- galp0[!is.na(seqnames(galp0))]
  GenomeInfoDb::seqlevels(galp0) <- as.character(unique(seqnames(region)))
  
  if(ignore.strand) {
    galp0 <- GenomicAlignments::coverage(galp0)[[1]]
  } else {
    galp_plus <- GenomicAlignments::coverage(galp0[GenomicAlignments::strand(galp0) == "+"])[[1]]
    galp_minus <- GenomicAlignments::coverage(galp0[GenomicAlignments::strand(galp0) == "-"])[[1]]
    galp0 <- GenomicAlignments::coverage(galp0)[[1]]
  }
  
  if(ignore.strand) {
    BiocGenerics::strand(region) <- "*"
  }
  
  if(S4Vectors::runValue(BiocGenerics::strand(region)) == "*") {
    depth <- galp0[BiocGenerics::start(region):BiocGenerics::end(region)]
  } else {
    if(S4Vectors::runValue(BiocGenerics::strand(region)) == "+") {
      depth <- galp_plus[BiocGenerics::start(region):BiocGenerics::end(region)]
    } else {
      depth <- galp_minus[BiocGenerics::start(region):BiocGenerics::end(region)]
    }
  }
  return(depth)
}





#' @title CumPos
#' @param x A vector of number.
#' 
CumPos <- function(x) {
  as.numeric(0.5 * (x - 1) + cumsum(c(1, x[-length(x)])))
}





#' @title GroupHeatSpot
#' 
#'
#' @importFrom GenomicRanges reduce
#' @importFrom BiocGenerics start
#' @importFrom BiocGenerics end
#' @importFrom Rsamtools BamFile
#' @importFrom GenomicAlignments readGAlignments
#' @importFrom parallel mclapply
#' @importFrom data.table as.data.table
#' @importFrom reshape2 melt
#' @import ggplot2
#' @import patchwork
#'
#' @param cells The cell types order to plot.
#' @param meta The sample information to plot.  
#' @param ColName The column name of cell types in the meta.
#' @param GeneID The gene ensembl ID.
#' @param Symbol The gene symbol ID.
#' @param BamFiles a file list of bamfiles
#' @param BamPostfix the postfix of bam files, remove the postfix the base name of bam must consistent with cells name
#' @param logTrans whether to perform log1p for the depth
#' @param ignore.strand the strandedness of bam file
#' @param ignore.SEorPE ignore single end paired of bamfiles (if your bam files have single end and paired end at the same time, you need to ignore the SEorPE)
#' @param antisense strandedness for singleEnd
#' @param strandMode strandMode for readGAlignments
#' @param mapqFilter A non-negative integer(1) specifying the minimum mapping quality to include. BAM records with mapping qualities less than mapqFilter are discarded.
#' @param geneModul A TxDb object made from GTF used by BAM aligner or a GRangesList object
#' @param shrinkage the shrinkage for intron region (must be a positive >= 1). default 1 for no shrinkage
#' @param high.col the color for high expressed base
#' @param low.col the color for low expressed base
#' @param reduce To collapse all gene structure annotation features or not
#' @param rel_heights The relative heights of each row in the grid (must be a vector with 4 numbers).
#' @param removeTxid logical value, indicating whether to remove the transcript of y axis lab
#' @param MinimumFractionForP The minimum fraction of scaled expression to calculate base pair waldtest P value
#' @param NT the cores for parallel
#'
#' 
#' @export
#' 

GroupHeatSpot <- function(cells = NULL,
                          meta = NULL,
                          ColName,
                          GeneID,
                          Symbol,
                          BamFiles,
                          BamPostfix,
                          logTrans = FALSE,
                          ignore.strand = TRUE,
                          ignore.SEorPE = FALSE,
                          antisense = TRUE,
                          strandMode = 2,
                          mapqFilter = 0,
                          geneModul,
                          shrinkage = 1,
                          high.col = "#0000FF80",
                          low.col =  "#FFFF0080",
                          reduce = FALSE,
                          rel_heights = c(1, 1),
                          removeTxid = FALSE,
                          MinimumFractionForP = 0.05,
                          NT = 1
                          ) {
  
  if(is.null(cells)) {
    cells <- row.names(meta)
  } else {
    cells <- cells[cells %in% row.names(meta)]
  }
  
  if(!all(file.exists(BamFiles))) {
    stop("all BamFiles file exists are FALSE")
  }
  
  if(!identical(sort(cells), sort(gsub(BamPostfix, "", basename(BamFiles))))) {
    stop("Bamfiles are not cover your cells or maybe your BamPostfix are wrong")
  }
  
  if(!is.logical(ignore.strand)) {
    stop("ignore.strand must be logical value")
  }
  
  if(!is.logical(removeTxid)) {
    stop("removeTxid must be logical value")
  }
  
  if(!is.logical(ignore.SEorPE)) {
    stop("ignore.SEorPE must be logical value")
  }
  
  if(!is.logical(logTrans)) {
    stop("logTrans must be logical value")
  }
  
  if(!is.logical(antisense)) {
    stop("antisense must be logical value")
  }
  
  if(length(strandMode) != 1) {
    stop("strandMode must be 1 or 2")
  }
  
  if(!is.element(strandMode, c(1, 2))) {
    stop("strandMode must be 1 or 2")
  }
  
  if(!is.numeric(mapqFilter)) {
    stop("mapqFilter must be a positive value")
  }
  
  if(mapqFilter < 0) {
    stop("mapqFilter must be a positive value")
  }
  
  if(!(is(geneModul, "TxDb") | is(geneModul, "GRangesList"))) {
    stop("geneModul must be a TxDb form GenomicFeatures or a GRangesList")
  }
  
  
  if(!is.numeric(NT)) {
    stop("NT must be a positive value")
  }
  
  if(!is.logical(reduce)) {
    stop("reduce must be logical value")
  }
  
  if(length(rel_heights) != 2) {
    stop("length of rel_heights must be 2")
  }
  
  if(any(!is.numeric(rel_heights))) {
    stop("rel_heights must be 2 positive numeric values")
  }
  
  if(any(rel_heights < 0)) {
    stop("rel_heights must be 2 positive numeric values")
  }
  
  if(NT <= 0) {
    stop("NT must be a positive value")
  }
  
  NT <- as.integer(NT)
  
  
  # rankcell <- row.names(meta[order(meta[[Cell_type]]), ])
  # rankcell <- rankcell[rankcell %in% cells]
  rankcell <- cells
  
  # gtffile <- GTF
  # txdb <- makeTxDbFromGFF(gtffile, format = "gtf", circ_seqs = character())
  
  region <- genes(geneModul)[GeneID,]
  
  ## Fig4 gene structure
  
  p4 <- plotgene(
    region = region,
    geneModul = geneModul,
    shrinkage = shrinkage,
    reduce = reduce,
    returnData = TRUE,
    removeTxid = removeTxid)
  
  if(is.list(p4) & length(p4) == 2) {
    plast <- p4[[1]]
  } else {
    plast <- p4
  }
  
  ## BAM reads processing
  
  parallel::mclapply(BamFiles, function(x) {
    if(ignore.SEorPE) {
      suppressWarnings(as.numeric(ReadBam(BamFile = x,
                                          region = region,
                                          ignore.strand = ignore.strand,
                                          singleEnd = TRUE,
                                          antisense = antisense,
                                          strandMode = strandMode,
                                          mapqFilter = mapqFilter)))
    } else {
      suppressWarnings(as.numeric(ReadBam(BamFile = x,
                                          region = region,
                                          ignore.strand = ignore.strand,
                                          singleEnd = FALSE,
                                          antisense = antisense,
                                          strandMode = strandMode,
                                          mapqFilter = mapqFilter
      )))
    }
  }, mc.cores = NT) -> base_reads
  
  ## BAM reads normalization
  
  if(logTrans) {
    base_reads_norm <- lapply(base_reads, function(x) log1p(x)/log1p(max(x)))
  } else {
    base_reads_norm <- lapply(base_reads, function(x) x/max(x))
  }
  
  base_reads_norm <- do.call(rbind, base_reads_norm)
  colnames(base_reads_norm) <- BiocGenerics::start(region):BiocGenerics::end(region)
  row.names(base_reads_norm) <- gsub(BamPostfix, "", basename(BamFiles))
  base_reads_norm <- base_reads_norm[rankcell, ]
  
  if(is.list(p4) & length(p4) == 2) {
    base_reads_norm <- base_reads_norm[, as.character(p4[[2]]$x)]
    colnames(base_reads_norm) <- p4[[2]]$x2
  }
  
  ## Fig1 Heat map
  
  annoMat <- data.frame(cell = factor(rankcell, levels = rankcell),
                        group = meta[rankcell, ColName],
                        pos = min(as.numeric(colnames(base_reads_norm)))) %>%
    mutate(group = factor(group, levels = unique(group)))
  
  lapply(seq_len(min(c(round(200 * 0.2), round(ncol(base_reads_norm)*0.01)))), function(i) {
    data.frame(cell = annoMat$cell, group = annoMat$group, pos = annoMat$pos + i)
  }) -> annoMat2
  annoMat2 <- do.call(rbind, annoMat2)
  
  base_reads_norm[is.na(base_reads_norm)]  <- 0
  base_reads_norm <- data.table::as.data.table(reshape2::melt(base_reads_norm))
  base_reads_norm[, Var1 := factor(Var1, levels = rankcell)]
  Mat1 <- base_reads_norm
  ggplot(Mat1, aes(x = Var2, y = as.numeric(Var1))) +
    geom_tile(aes(fill = value), show.legend = FALSE) +
    theme_classic() +
    scale_fill_gradient(high = high.col, low = low.col) +
    geom_point(data = annoMat2, aes(x = pos, y = as.numeric(cell), colour = group), shape = 15, size = 1) +
    theme(legend.position = "none",
          axis.line.x = element_blank(),
          axis.line.y = element_line(size = 0.1, color = "white"),
          axis.text.x = element_blank(),
          axis.text.y = element_text(size = 14),
          axis.title = element_blank(),
          axis.ticks = element_blank(),
          plot.title = element_text(hjust = 0.5, size = 20)
    ) +
    guides(colour = guide_legend(override.aes = list(size = 3))) +
    labs(title = GeneID) +
    scale_y_continuous(breaks = CumPos(table(annoMat$group)), labels = levels(annoMat$group))+
    scale_x_continuous(expand = c(0, 0)) -> p1
  
  if(!is.na(Symbol)){
    p1 <- p1 + labs(title = paste0(Symbol," - ",GeneID))
  }
  
  if(any(rel_heights == 0)) {
    ps <- list(p1, plast)
    ps <- ps[rel_heights != 0]
    
    if(length(ps) == 1) {
      print(ps[[1]])
    } else {
      if(length(ps) == 2) {
        ps[[1]] / ps[[2]] + patchwork::plot_layout(heights = rel_heights[rel_heights != 0])
      } else {
        ps[[1]] / ps[[2]] / ps[[3]] + patchwork::plot_layout(heights = rel_heights[rel_heights != 0])
      }
    }
  } else {
    (p1 / plast) + patchwork::plot_layout(heights = rel_heights)
  }
}


