#' @title OverlapGenes
#' @name OverlapGenes
#' @description The function \code{OverlapGenes} is used to identified the overlapped genes. If the strand is 1 or 2, the overlap genes are defined to
#' the genes located in the same strand, else do not consider the strandMode.
#'
#'
#' @param Strand The \code{Strand} including the 0,1,2 values.
#' @param gtfFile The gtf annotation files.
#'
#' @return A vector of overlapped genes ensembl IDs.
#'
#'
#' @importFrom GenomicAlignments findOverlaps
#' @importFrom IRanges IRanges
#' @importFrom GenomicRanges GRanges
#' @importFrom rtracklayer readGFF
#' @importFrom IRanges slice
#' @importFrom S4Vectors subjectHits
#'
#'


OverlapGenes <- function(Strand = 2, gtfFile) {

  if (!file.exists(gtfFile)) {
    stop("Your gtf file is not exist.")
  }

  if (!(Strand %in% c(0,1,2))) {
    stop("The Strand should be setted to 0,1,2 values.")
  }


  gtf <- rtracklayer::readGFF(gtfFile)
  all_gene <- gtf[gtf$type == 'gene',]
  gr <- GRanges(
    seqnames = as.vector(all_gene[, 1]),
    ranges = IRanges(start = all_gene[, 4], end = all_gene[, 5]),
    strand = as.vector(all_gene[, 7]),
    gene_id = all_gene[, 9]
  )

  if (Strand == 1 | Strand == 2) {
    gr_rle_plus <- coverage(gr[strand(gr) == "+"])
    gr_rle_minus <- coverage(gr[strand(gr) == "-"])

    ## find overlap regions
    overlap_IRange_plus <- ranges(IRanges::slice(gr_rle_plus, lower = 2))
    overlap_IRange_minus <- ranges(IRanges::slice(gr_rle_minus, lower = 2))
    overlap_DF_plus <- data.frame(unlist(overlap_IRange_plus))
    overlap_DF_minus <- data.frame(unlist(overlap_IRange_minus))

    ## creat GRanges object
    overlap_GRange_plus <- GRanges(
      seqnames = overlap_DF_plus$names,
      ranges = IRanges(start = overlap_DF_plus$start, end =
                         overlap_DF_plus$end),
      strand = rep('+', nrow(overlap_DF_plus))
    )
    overlap_GRange_minus <- GRanges(
      seqnames = overlap_DF_minus$names,
      ranges = IRanges(start = overlap_DF_minus$start, end =
                         overlap_DF_minus$end),
      strand = rep('-', nrow(overlap_DF_minus))
    )

    overlap_Hits_plus <- findOverlaps(overlap_GRange_plus, gr)
    overlap_Hits_minus <- findOverlaps(overlap_GRange_minus, gr)

    overlap_genes_plus <-
      unique(unlist(gr$gene_id)[subjectHits(overlap_Hits_plus)])
    overlap_genes_minus <-
      unique(unlist(gr$gene_id)[subjectHits(overlap_Hits_minus)])

    overlap_genes <-
      unique(c(overlap_genes_plus, overlap_genes_minus))

  } else {
    gr_rle <- coverage(gr)
    overlap_IRangeList <- ranges(IRanges::slice(gr_rle, lower = 2))
    gr_GRangeList <- split(gr, seqnames(gr))

    overlap_Hits <-
      findOverlaps(overlap_IRangeList, ranges(gr_GRangeList))

    overlap_genes <- lapply(1:length(gr_GRangeList), function(i) {
      tmp <-
        unique(unlist(gr_GRangeList[[i]]$gene_id)[subjectHits(overlap_Hits[[i]])])
    })
    overlap_genes <- unique(unlist(overlap_genes))
  }
}







#' @title intronProcess
#' @name intronProcess
#' @description The \code{intronProcess} is used to calculate the changes in post-transcriptional regulation that can be predicted from differences between exonic and intronic changes \code{Δexon-Δintron} or ratio \code{(exonC1/exonC2)-(intronC1/intronC2)}.
#' The function returns a list including \code{delt_exon(Ratio_exon)}, \code{delt_intron(Ratio_intron)} and \code{common_results}.
#'
#'
#' @param object A EIQuantifyList from the \code{EI_quantify} function.
#' @param gtfFile The gtf annotation files.
#' @param Strand (Default 2) The strand mode including the 0,1,2 values.
#' @param contrast This argument specifies what comparison to extract from the \code{object} to calculate differential counts.
#' A character vector with exactly three elements: the name of a factor including the variable of experiment design;
#' the name of the subtrahend(numerator) level for the fold change; the name of the minuend(denominator) level for the fold change.
#' For example, \code{c("condition","B","A")}. In addition, the \code{c("condition","B","Average")} is used to calculate the differentials between conditionB and  the average over all conditions.
#' @param rowMean (Default 5) The mean of exonic/intronic reads counts \code{log2(normalization+1)} per gene across all replications in a same condition, uesd to filter low expression genes.
#' @param outOverlapgenes (Default FALSE) Whether the results need to be filtered out of overlapped genes. And only when \code{outOverlapgenes=TRUE}, the parameters that \code{gtfFile} and \code{Strand} are required.
#' @param calcuType Two calculation types: \code{delta} and \code{ratio}. The \code{delta} method calculates the difference between exonic and intronic changes; the \code{ratio} calculate the difference between exonic and intronic ratio.
#' @param cores (Default 5) Using multiple cores.
#'
#'
#' @return A list including the two vectors and one data frame: \code{delt_exon(Ratio_exon)}, \code{delt_intron(Ratio_intron)} and \code{common_results}. The delt_exon and the delt_intron are the exonic reads difference and the intronic reads difference of two experiment conditions in \code{contrast}, respectively.
#' The Ratio_exon and the Ratio_intron are the exonic reads ratio and the intronic reads ratio of two experiment conditions in \code{contrast}, respectively. The \code{common_results} shows the change of delt_exon and delt_intron or the change of the Ratio_exon and Ratio_intron.
#'
#'
#'
#' @import DESeq2
#' @import pryr
#' @importFrom lmtest waldtest
#' @importFrom reshape2 melt
#' @importFrom stats lm
#'
#' @examples
#' # GTF <- "/mnt/raid61/Personal_data/chenli/REF/GRCm38.93/Mus_musculus.GRCm38.93.gtf"
#' # res_HSC <- intronProcess(myEIQuantifyList,
#' #                           gtfFile = GTF,
#' #                           Strand = 2,
#' #                           calcuType = "delta",
#' #                           outOverlapgenes = TRUE,
#' #                           contrast = c("CellType", "ST-HSC", "LT-HSC"))
#'
#'
#' @export

intronProcess = function(object,
                         gtfFile,
                         Strand = 2,
                         contrast,
                         rowMean = 5,
                         outOverlapgenes = FALSE,
                         calcuType,
                         cores = 5) {

  if (!(class(object) == "EIQuantifyList")) {
    stop("The input object must be the 'EIQuantifyList' class.")
  }

  if (outOverlapgenes == TRUE) {
    overlap_genes <- OverlapGenes(Strand = Strand, gtfFile = gtfFile)
    sub_counts_exon <-
      object@counts_exon[setdiff(rownames(object@counts_exon), overlap_genes), ]
    sub_counts_intron <-
      object@counts_intron[setdiff(rownames(object@counts_intron), overlap_genes), ]
  } else {
    sub_counts_exon <- object@counts_exon
    sub_counts_intron <- object@counts_intron
  }

  SampleInfo <- object@SampleInfo

  ###### filter genes (normalize, add pseudo-counts of 1, log2 transform, rowMean>5, and overlapping genes)
  ## exonic reads counts
  dds_exon <- DESeqDataSetFromMatrix(countData = sub_counts_exon,
                                     colData = SampleInfo,
                                     design = ~ 1)

  exon_log2 <-
    log2(counts(estimateSizeFactors(dds_exon), normalized = TRUE) + 8)
  exon_filter_log2 <- exon_log2[rowMeans(exon_log2) >= rowMean, ]

  ## intronic reads counts
  dds_intron <- DESeqDataSetFromMatrix(countData = sub_counts_intron,
                                       colData = SampleInfo,
                                       design = ~ 1)

  intron_log2 <-
    log2(counts(estimateSizeFactors(dds_intron), normalized = TRUE) + 8)
  intron_filter_log2 <- intron_log2[rowMeans(intron_log2) >= rowMean, ]



  ###### calculate
  ## delt_exon
  sub_e1 <- data.frame(exon_filter_log2[, grep(paste0("^",contrast[2]), SampleInfo[[contrast[1]]])])
  Treat_e1_mean <- round(rowMeans(sub_e1), 2)
  n1 <- ncol(sub_e1)

  if(contrast[3] == "Average"){
    sub_e2 <-
      data.frame(Average_1 = rowMeans(do.call(cbind, lapply(unique(SampleInfo[[contrast[1]]]), function(x) {
        exon_filter_log2[, grep(paste0("^", x, "$"), SampleInfo[[contrast[1]]])[1]]
      }))),
      Average_2 = rowMeans(do.call(cbind, lapply(unique(SampleInfo[[contrast[1]]]), function(x) {
        exon_filter_log2[, setdiff(grep(paste0("^", x, "$"), SampleInfo[[contrast[1]]]),
                                   grep(paste0("^", x, "$"), SampleInfo[[contrast[1]]])[1])]
      }))))

    Treat_e2_mean <- round(rowMeans(sub_e2), 2)
    n2 <- ncol(sub_e2)

  } else {
    sub_e2 <- data.frame(exon_filter_log2[, grep(paste0("^",contrast[3]), SampleInfo[[contrast[1]]])])
    Treat_e2_mean <- round(rowMeans(sub_e2), 2)
    n2 <- ncol(sub_e2)
  }

  ### wald.test
  df_e <- cbind(sub_e1,sub_e2)
  waldtest_F_exon <- mclapply(seq_len(nrow(df_e)), function(y){
    Exp = as.numeric(unlist(df_e[y,]))
    CType = rep(c("C1","C2"),times = c(n1,n2))

    fit <- lm(Exp ~ CType)
    waldtest_F <-
      tryCatch(
        waldtest(fit, test = "F")$`Pr(>F)`[2],
        error = function(e)
          NA
      )

  },mc.cores = cores)

  df_e$delt_exon <- Treat_e1_mean - Treat_e2_mean
  df_e$ratio_exon <- Treat_e1_mean/Treat_e2_mean
  df_e$waldtest_F_Exon <- unlist(waldtest_F_exon)



  ## delt_intron
  sub_i1 <- data.frame(intron_filter_log2[, grep(paste0("^",contrast[2]), SampleInfo[[contrast[1]]])])
  Treat_i1_mean <- round(rowMeans(sub_i1), 2)
  n3 <- ncol(sub_i1)

  if(contrast[3] == "Average"){
    sub_i2 <-
      data.frame(Average_1 = rowMeans(do.call(cbind, lapply(unique(SampleInfo[[contrast[1]]]), function(x) {
        intron_filter_log2[, grep(paste0("^", x, "$"), SampleInfo[[contrast[1]]])[1]]
      }))),
      Average_2 = rowMeans(do.call(cbind, lapply(unique(SampleInfo[[contrast[1]]]), function(x) {
        intron_filter_log2[, setdiff(grep(paste0("^", x, "$"), SampleInfo[[contrast[1]]]),
                                     grep(paste0("^", x, "$"), SampleInfo[[contrast[1]]])[1])]
      }))))

    Treat_i2_mean <- round(rowMeans(sub_i2), 2)
    n4 <- ncol(sub_i2)

  } else {
    sub_i2 <- data.frame(intron_filter_log2[, grep(paste0("^",contrast[3]), SampleInfo[[contrast[1]]])])
    Treat_i2_mean <- round(rowMeans(sub_i2), 2)
    n4 <- ncol(sub_i2)
  }

  ### wald.test
  df_i <- cbind(sub_i1,sub_i2)
  waldtest_F_intron <- mclapply(seq_len(nrow(df_i)), function(y){
    Exp = as.numeric(unlist(df_i[y,]))
    CType = rep(c("C1","C2"),times = c(n3,n4))

    fit <- lm(Exp ~ CType)
    waldtest_F <-
      tryCatch(
        waldtest(fit, test = "F")$`Pr(>F)`[2],
        error = function(e)
          NA
      )

  },mc.cores = cores)

  df_i$delt_intron <- Treat_i1_mean - Treat_i2_mean
  df_i$ratio_intron <- Treat_i1_mean/Treat_i2_mean
  df_i$waldtest_F_Intron <- unlist(waldtest_F_intron)



  if(calcuType == "delta"){
    ## delt_exon - delt_intron
    common_genes <- intersect(rownames(df_e), rownames(df_i))
    deviation_delt <-  df_e[common_genes,"delt_exon"] - df_i[common_genes,"delt_intron"]

    common_results <-
      data.frame(
        delt_exon = df_e[common_genes,"delt_exon"],
        delt_intron = df_i[common_genes,"delt_intron"],
        deviation_delt = deviation_delt,
        row.names = common_genes
      )

    results <-
      list(
        delt_exon = df_e,
        delt_intron = df_i,
        common_results = common_results
      )
  } else if(calcuType == "ratio"){
    ## (exonC1/exonC2)-(intronC1/intronC2)
    common_genes <- intersect(rownames(df_e), rownames(df_i))
    deviation_Ratio <- df_e[common_genes,"ratio_exon"] - df_i[common_genes,"ratio_intron"]

    common_results <-
      data.frame(Rexon = df_e[common_genes, "ratio_exon"],
                 Rintron = df_i[common_genes, "ratio_intron"],
                 deviation_Ratio = deviation_Ratio,
                 row.names = common_genes)

    results <-
      list(
        Ratio_exon = df_e,
        Ratio_intron = df_i,
        common_results = common_results
      )
  }
  return(results)
}




