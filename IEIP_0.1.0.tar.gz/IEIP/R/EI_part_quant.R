#' @title EI_part_quant
#' @name EI_part_quant
#' @description The function \code{EI_part_quant} is used to quantify the expression of the exonicparts and introns from per gene.
#'
#'
#' @param object A EIQuantifyList from the \code{EI_quantify} function.
#' @param useHTSeq (Default TRUE) A logical. when \code{useHTSeq=TRUE}, directly loading quantification results by HTSeq python script;
#' and when \code{useHTSeq=FALSE}, counting exonic and intronic reads per gene by \code{summarizeOverlaps} from \code{GenomicAlignments} package that are same as HTSeq results.
#' \code{inter.feature}, \code{singleEnd}, \code{fragments} and \code{strandMode} are applied.
#' @param filepath The file path of your HTSeq result file(s) or bam file(s).
#' @param pattern The suffix of your HTSeq result file(s) that including exonic and intronic files, or the suffix of bam file(s).
#' @param ColName The character indicates the the colname including the sample names and be included in the SampleInfo.
#' @param intronicPart A CompressedGRangesList object. The region including "intron" feature.
#' @param exonicPart A GRanges object. The region including "exon" feature.
#' @param chromosome (Default 21) When identifying the strand by \code{CheckStrand}, we only used one chromosome of all genome.
#' @param mode,inter.feature,singleEnd,fragments  Additional arguments are included in the \code{summarizeOverlaps} function. Please \code{?summarizeOverlaps}.
#' @param mc.cores (Default 5) Using multiple cores.
#'
#'
#' @return A S4 object of the class "EIQuantifyList" including six slots
#' \code{counts_exon} stores the raw exonic counts of genes across all samples. \code{counts_intron} stores the raw intronic counts of genes across all samples. \code{SampleInfo} stores the samples information.
#' \code{seq_info} stores the sequencing informations. \code{region} stores the exonicPart and intronicPart regions. \code{exonicAndintronic} stores the counts of the exonic and intronic regions.
#'
#'
#' @import GenomicAlignments
#' @import BiocParallel
#' @import GenomicFeatures
#' @import GenomicRanges
#' @import Rsamtools
#' @import SummarizedExperiment
#' @import DESeq2
#' @import pryr
#' @import methods
#' @import parallel
#'
#'
#' @examples
#' # myEIQuantifyList <- EI_part_quant(myEIQuantifyList,
#' #                                   intronicPart = intronicPart,
#' #                                   exonicPart = exonicPart,
#' #                                   ColName = "Run",
#' #                                   filepath = "/mnt/raid63/HSC/mouse/bulk/chenghui_MmBlood/align",
#' #                                   pattern = ".Aligned.sortedByCoord.out.bam",
#' #                                   singleEnd = FALSE,
#' #                                   inter.feature= TRUE,mc.cores = 10)
#'
#' @export
#'

EI_part_quant <- function(object,
                          exonicPart,
                          intronicPart,
                          ColName,
                          filepath,
                          pattern,
                          chromosome = 21,
                          mode = "Union",
                          useHTSeq = FALSE,
                          inter.feature = FALSE,
                          singleEnd = TRUE,
                          fragments = FALSE,
                          mc.cores = 5) {
  if (class(object) != "EIQuantifyList") {
    stop("The input object must be the 'EIQuantifyList' class.")
  }
  if (class(exonicPart) != "GRanges" &
      class(exonicPart) != "CompressedGRangesList") {
    stop("The input object must be the 'GRanges' or 'CompressedGRangesList' class.")
  }
  if (class(intronicPart) != "CompressedGRangesList") {
    stop("The input object must be the 'CompressedGRangesList' class.")
  }


  if (useHTSeq == FALSE) {
    ## exon part
    exonicPart$class <- "e"

    names(exonicPart) <-
      paste0(seqnames(exonicPart),
             ":",
             ranges(exonicPart),
             ":",
             strand(exonicPart))
    exonicPart <- exonicPart[width(ranges(exonicPart)) > 1]


    ## intron region
    intronPart <- unlist(intronicPart)
    intronPart$gene_id <- names(intronPart)
    intronPart$class <- "i"

    names(intronPart) <-
      paste0(seqnames(intronPart),
             ":",
             ranges(intronPart),
             ":",
             strand(intronPart))
    intronPart <- intronPart[width(ranges(intronPart)) > 1]


    all_bins <- c(exonicPart, intronPart)


    ## quantification

    filenames <-
      file.path(filepath, paste0(object@SampleInfo[[ColName]], pattern))

    if (!all(file.exists(filenames))) {
      stop("Your bam files are not exist.")
    }

    bamfiles <- BamFileList(filenames, yieldSize = 2000000)

    ## filter
    flag <- scanBamFlag(
      isSecondaryAlignment = FALSE,
      isNotPassingQualityControls = FALSE,
      isUnmappedQuery = FALSE,
      isDuplicate = FALSE
    )
    sbp <- ScanBamParam(flag = flag, mapqFilter = 255)


    ## check strand
    ### transform strand
    ReverseReads <- function(reads = reads) {
      reads <- as(reads, "GRanges")
      strand(reads) <- ifelse(strand(reads) == "+", "-", "+")
      return(reads)
    }

    if (nrow(object@seq_info) == 0) {
      seq_info <-
        StrandSpecific(
          bamFile = filenames[1],
          TxDb = txdb_i,
          organism = "NULL",
          reference = "NULL",
          cores = 4,
          GTF = NULL,
          chromosome = chromosome,
          singleEnd = singleEnd
        )
    }

    options(srapply_fapply = "parallel", mc.cores = mc.cores)

    if (seq_info$strand == 0) {
      ignore.strand = TRUE
      preprocess.reads = NULL
    } else if (seq_info$strand == 2 &
               seq_info$layout == "Single-End") {
      ignore.strand = FALSE
      preprocess.reads = ReverseReads
    } else if (seq_info$strand == 2 &
               seq_info$layout == "Paired-End") {
      ignore.strand = FALSE
    } else {
      ignore.strand = FALSE
      preprocess.reads = NULL
    }


    ## count
    if (singleEnd == TRUE) {
      se <-
        summarizeOverlaps(
          features = all_bins,
          reads = bamfiles,
          mode = mode,
          ignore.strand = ignore.strand,
          inter.feature = inter.feature,
          singleEnd = singleEnd,
          param = sbp,
          preprocess.reads = preprocess.reads
        )

    } else {
      se <-
        summarizeOverlaps(
          features = all_bins,
          reads = bamfiles,
          mode = mode,
          param = sbp,
          ignore.strand = ignore.strand,
          inter.feature = inter.feature,
          singleEnd = singleEnd,
          fragments = fragments,
          strandMode = seq_info$strand,
          preprocess.reads = NULL
        )

    }

    colData(se) <- DataFrame(object@SampleInfo)
    dds <- DESeqDataSet(se, design = ~ 1)

    norm_log2 <-
      log2(counts(estimateSizeFactors(dds), normalized = TRUE) + 1)

    object@seq_info <- seq_info

  } else {
    SampleInfo <- data.frame(object@SampleInfo)
    counts_exon <-
      Countsmerge(
        filepath = filepath,
        pattern = pattern[1],
        SampleInfo = SampleInfo,
        ColName = ColName
      )
    counts_intron <-
      Countsmerge(
        filepath = filepath,
        pattern = pattern[2],
        SampleInfo = SampleInfo,
        ColName = ColName
      )

    #### exon
    exonPart <- unlist(exonicPart)
    exonPart$gene_id <- names(exonPart)
    exonPart$class <- "e"

    names(exonPart) <-
      paste0(seqnames(exonPart),":",ranges(exonPart),":",strand(exonPart))

    #### intron
    intronPart <- unlist(intronicPart)
    intronPart$gene_id <- names(intronPart)
    intronPart$class <- "i"

    names(intronPart) <-
      paste0(seqnames(intronPart),":",ranges(intronPart),":",strand(intronPart))


    all_bins <- c(exonPart, intronPart)

    rownames(counts_exon) <-
      names(exonPart[match(rownames(counts_exon),
                             gsub(";.*", "", exonPart$exon_name))])
    rownames(counts_intron) <-
      names(intronPart[match(rownames(counts_intron),
                             gsub(";.*", "", intronPart$exon_name))])

    all_counts <- rbind(counts_exon, counts_intron)
    all_counts[is.na(all_counts)] <- 0

    dds <-
      DESeqDataSetFromMatrix(
        countData = all_counts,
        colData = SampleInfo,
        design = ~ 1
      )
    norm_log2 <-
      log2(counts(estimateSizeFactors(dds), normalized = TRUE) + 1)

  }

  object@region <- all_bins
  object@exonicAndintronic <- norm_log2

  return(object)
}








#' @title PlotLine
#' @name PlotLine
#' @description The function \code{PlotLine} is used to plot the expression of the exonicparts and introns from a gene.
#'
#'
#' @param object A EIQuantifyList from the \code{EI_quantify} function.
#' @param GeneID A gene Ensembl ID.
#' @param ColName The character indicates the the colname including the sample names and be included in the SampleInfo.
#' @param Type A character vector.
#'
#'
#' @return A ggplot
#'
#'
#' @import ggplot2
#' @importFrom dplyr %>%
#' @importFrom dplyr mutate
#' @importFrom dplyr group_by
#' @importFrom dplyr summarize
#' @importFrom reshape2 melt
#' @importFrom S4Vectors DataFrame
#'
#'
#' @examples
#' # PlotLine(myEIQuantifyList,GeneID= "ENSMUSG00000017057",ColName = "CellType",
#' #          Type = c("LT-HSC","ST-HSC","MPP","MEP"))
#'
#' @export
#'

PlotLine <- function(object,
                     GeneID,
                     ColName,
                     Type) {

  rg <- object@region[object@region$gene_id == GeneID]
  col = rownames(object@SampleInfo[object@SampleInfo[[ColName]] %in% Type,])
  n = length(Type)


  df <- reshape2::melt(object@exonicAndintronic[names(rg),col])  %>%
    mutate(CellType = gsub("_.*", "", .$Var2)) %>%
    group_by(CellType,Var1) %>%
    summarize(meanValue = mean(value)) %>%
    data.frame %>%
    mutate(
      Start = do.call(rbind, strsplit(as.character(.$Var1), split = "[:-]"))[, 2],
      End = do.call(rbind, strsplit(as.character(.$Var1), split = "[:-]"))[, 3],
      class = rep(rg$class, n),
      width  = rep(width(rg), n)
    ) %>%
    mutate(Start = as.numeric(Start),
           End = as.numeric(End))


  df <- do.call(rbind, lapply(unique(df$CellType), function(x) {
    tmp <- subset(df, CellType == x)
    tmp <- tmp[order(tmp$Start),]
  })) %>%
    mutate(Start2 = rep(seq(1, 500 * length(unique(
      .$Var1
    )), 500), n),
    End2 = rep(seq(500, 500 * length(unique(
      .$Var1
    )), 500), n))


  df2 <- data.frame(
    Var1 = rep(df$Var1, 2),
    CellType = rep(df$CellType, 2),
    meanValue = rep(df$meanValue, 2),
    Position = c(df$Start2, df$End2),
    class = rep(df$class, 2),
    width = rep(df$width, 2)
  ) %>%
    mutate(CellType = factor(.$CellType, levels = Type))



  anno <-
    data.frame(
      x = rep(seq(250, 500 * length(unique(df2$Var1)), 500), n),
      y = max(df2$meanValue) + 0.5,
      lab1 = df2$class[1:(length(df2$class) / 2)],
      lab2 = df2$width[1:(length(df2$width) / 2)]
    )


  ggplot(data = df2,
         aes(
           x = Position,
           y = meanValue,
           group = CellType,
           color = CellType
         )) +
    geom_line() +
    theme_classic() +
    theme(axis.title.x = element_blank()) +
    annotate("text",
             x = unique(anno$x),
             y = max(df2$meanValue) + 0.5,
             label = unique(df[,c(6:9)])$width,
             size = 2) +
    annotate("pointrange",
             x = subset(unique(anno),lab1=="e")$x,
             xmin = subset(unique(df[,c(6:9)]),class == "e")$Start2,
             y = max(df2$meanValue) + 0.7,
             xmax = subset(unique(df[,c(6:9)]),class == "e")$End2,
             color = "blue",
             size = 0.1) +
    annotate("pointrange",
             x = subset(unique(anno),lab1=="i")$x,
             xmin = subset(unique(df[,c(6:9)]),class == "i")$Start2,
             y = max(df2$meanValue) + 0.7,
             xmax = subset(unique(df[,c(6:9)]),class == "i")$End2,
             color = "green",
             size = 0.1) +
    labs(title = GeneID)


}






