#' @author Chen Li
#' @title Countsmerge
#' @name Countsmerge
#' @description The function \code{Countsmerge} is used to summarize the HTSeq results.
#'
#'
#' @param filepath The file path of your HTSeq result file(s).
#' @param pattern The suffix of your HTSeq result file(s).
#' @param SampleInfo The data frame shows the sample infomation.
#' @param ColName The character indicates the the colname including the sample names and be included in the SampleInfo.
#'
#' @return A data.frame with the quantification results of HTSeq. The columes show the sample names and the rows show the gene names.
#'
#' @importFrom data.table fread
#' @importFrom data.table setnames
#' @importFrom data.table setDF
#' @importFrom tibble column_to_rownames
#' @importFrom utils tail
#'

Countsmerge = function(filepath,
                       pattern,
                       SampleInfo,
                       ColName) {

  if (!(ColName %in% colnames(SampleInfo))) {
    stop("SampleInfo must include the column of ColName.")
  }

  SampleInfo <- data.frame(SampleInfo)
  filenames = file.path(filepath, paste0(SampleInfo[[ColName]], pattern))

  if (!all(file.exists(filenames))) {
    stop("Your filepath are not a file.path or this file are not exist.")
  }


  datalist = lapply(filenames, function(x) {
    tmp <- fread(x, header = FALSE)
    tmp <- tmp[1:(nrow(tmp) - 5), ]
    colnames(tmp)[1] <- 'gene_id'
    setnames(tmp, "V2", gsub(pattern, "", tail(strsplit(x, "/")[[1]], n = 1)))
    return(tmp)
  })
  dt = Reduce(function(x, y) {
    merge(x, y, all = T, by = "gene_id")
  }, datalist)
  column_to_rownames(setDF(dt), var = 'gene_id')
}




#' @title The EIQuantifyList Class
#'
#' @import methods
#'
#'
EIquantifylist <- setClass(
  "EIQuantifyList",
  representation(
    counts_exon = "data.frame",
    counts_intron = "data.frame",
    SampleInfo = "data.frame",
    seq_info = "data.frame",
    region = "ANY",
    exonicAndintronic = "ANY"
  )
)

setGeneric("Subset", function(object, i, drop)
  standardGeneric("Subset"))
setMethod(
  f          = "Subset",
  signature  = "EIQuantifyList",
  definition = function(object, i, drop) {
    return(
      new(
        "EIQuantifyList",
        counts_exon = object@counts_exon[, i],
        counts_intron = object@counts_intron[, i],
        SampleInfo = object@SampleInfo[i,],
        seq_info = object@seq_info,
        region = object@region,
        exonicAndintronic = object@exonicAndintronic
      )
    )
  }
)







#' @title EI_quantify
#' @name EI_quantify
#' @description The function \code{EI_quantify} is used to count exonic and intronic reads per gene or load data from HTSeq outputs.
#'
#'
#' @param useHTSeq (Default TRUE) A logical. when \code{useHTSeq=TRUE}, directly loading quantification results by HTSeq python script;
#' and when \code{useHTSeq=FALSE}, counting exonic and intronic reads per gene by \code{summarizeOverlaps} from \code{GenomicAlignments} package that are same as HTSeq results.
#' Only when \code{useHTSeq=FALSE}, these parameters that \code{gtf_exon}, \code{gtf_intron}, \code{mode}, \code{ignore.strand},
#' \code{inter.feature}, \code{singleEnd}, \code{fragments} and \code{strandMode} are applied.
#' @param filepath The file path of your HTSeq result file(s) or bam file(s).
#' @param pattern The suffix of your HTSeq result file(s) that including exonic and intronic files, or the suffix of bam file(s).
#' @param SampleInfo The data frame shows the sample infomation.
#' @param ColName The character indicates the the colname including the sample names and be included in the SampleInfo.
#' @param gtf_exon The gtf file including "exon" feature.
#' @param gtf_intron The gtf file including "intron" feature.
#' @param chromosome (Default 21) When identifying the strand by \code{CheckStrand}, we only used one chromosome of all genome.
#' @param mode,inter.feature,singleEnd,fragments  Additional arguments are included in the \code{summarizeOverlaps} function. Please \code{?summarizeOverlaps}.
#' @param mc.cores (Default 2) Using multiple cores.
#'
#'
#' @return A S4 object of the class "EIQuantifyList" including four slots
#' \code{counts_exon} stores the raw exonic counts of genes across all samples. \code{counts_intron} stores the raw intronic counts of genes across all samples. \code{SampleInfo} stores the samples information.
#' \code{seq_info} stores the sequencing informations.
#'
#'
#' @import GenomicAlignments
#' @import BiocParallel
#' @import GenomicFeatures
#' @import GenomicRanges
#' @import Rsamtools
#' @import SummarizedExperiment
#' @import DESeq2
#' @import pryr
#'
#' @examples
#' # library(IEIP)
#' # metainfo <- readRDS("/mnt/raid61/AS_Evolution/blood/meta/blood.Hs_Mm_meta.Rds")
#' # Quanfiles <- "/mnt/raid61/Personal_data/chenli/Bloodmm_chenhui/HTSeq_results"
#' # myEIQuantifyList <- EI_quantify(SampleInfo = metainfo[["MusMus"]][[1]],
#' #                                    ColName = "Run",
#' #                                   filepath = Quanfiles,
#' #                                    pattern = c(".Exons.counts.txt",".Intron.counts.txt"),
#' #                                   useHTSeq = TRUE
#' #                                 )
#'
#'
#' @export
#'

EI_quantify = function(SampleInfo,
                       ColName,
                       filepath,
                       pattern,
                       gtf_exon,
                       gtf_intron,
                       chromosome = 21,
                       mode = "Union",
                       inter.feature = FALSE,
                       singleEnd = TRUE,
                       fragments = FALSE,
                       useHTSeq = FALSE,
                       mc.cores = 2) {

  if (!(ColName %in% colnames(SampleInfo))) {
    stop("SampleInfo must include the column of ColName.")
  }

  if (!(is.logical(useHTSeq))) {
    stop("The param useHTSeq should be a logical.")
  }


  options(srapply_fapply = "parallel", mc.cores = mc.cores)
  SampleInfo <- data.frame(SampleInfo)

  if (useHTSeq == FALSE) {
    filenames <-
      file.path(filepath, paste0(SampleInfo[[ColName]], pattern))

    if (!all(file.exists(filenames))) {
      stop("Your bam files are not exist.")
    }

    bamfiles <- BamFileList(filenames, yieldSize = 2000000)

    ## exon
    gtf_e <- gtf_exon
    txdb_e <-
      makeTxDbFromGFF(gtf_e, format = "gtf", circ_seqs = character())
    ebg_exon <- exonsBy(txdb_e, by = "gene")


    ## intron
    gtf_i <- gtf_intron
    txdb_i <-
      makeTxDbFromGFF(gtf_i, format = "gtf", circ_seqs = character())
    ebg_intron <- exonsBy(txdb_i, by = "gene")

    ## filter
    flag <- scanBamFlag(
      isSecondaryAlignment = FALSE,
      isNotPassingQualityControls = FALSE,
      isUnmappedQuery = FALSE,
      isDuplicate = FALSE
    )
    sbp <- ScanBamParam(flag = flag, mapqFilter = 255)

    ## check strand
    ### transform strand
    ReverseReads <- function(reads = reads) {
      reads <- as(reads, "GRanges")
      strand(reads) <- ifelse(strand(reads) == "+", "-", "+")
      return(reads)
    }

    seq_info <-
      StrandSpecific(bamFile = filenames[1],
                     TxDb = txdb_e,
                     organism = "NULL",
                     reference = "NULL",
                     cores = 4,
                     GTF = NULL,
                     chromosome = chromosome,
                     singleEnd = singleEnd)
    print(seq_info)

    if (seq_info$strand == 0) {
      ignore.strand = TRUE
      preprocess.reads = NULL
    } else if (seq_info$strand == 2 &
               seq_info$layout == "Single-End") {
      ignore.strand = FALSE
      preprocess.reads = ReverseReads
    } else if (seq_info$strand == 2 &
               seq_info$layout == "Paired-End") {
      ignore.strand = FALSE
    } else if (seq_info$strand == 1) {
      ignore.strand = FALSE
      preprocess.reads = NULL
    }


    ## count
    if (singleEnd == TRUE) {
      se_exon <-
        summarizeOverlaps(
          features = ebg_exon,
          reads = bamfiles,
          mode = mode,
          ignore.strand = ignore.strand,
          inter.feature = inter.feature,
          singleEnd = singleEnd,
          param = sbp,
          preprocess.reads = preprocess.reads
        )
      se_intron <-
        summarizeOverlaps(
          features = ebg_intron,
          reads = bamfiles,
          mode = mode,
          ignore.strand = ignore.strand,
          inter.feature = inter.feature,
          singleEnd = singleEnd,
          param = sbp,
          preprocess.reads = preprocess.reads
        )
    } else {
      se_exon <-
        summarizeOverlaps(
          features = ebg_exon,
          reads = bamfiles,
          mode = mode,
          param = sbp,
          ignore.strand = ignore.strand,
          inter.feature = inter.feature,
          singleEnd = singleEnd,
          fragments = fragments,
          strandMode = seq_info$strand,
          preprocess.reads = NULL
        )
      se_intron <-
        summarizeOverlaps(
          features = ebg_intron,
          reads = bamfiles,
          mode = mode,
          param = sbp,
          ignore.strand = ignore.strand,
          inter.feature = inter.feature,
          singleEnd = singleEnd,
          fragments = fragments,
          strandMode = seq_info$strand,
          preprocess.reads = NULL
        )
    }

    counts_exon <- data.frame(assay(se_exon))
    counts_intron <- data.frame(assay(se_intron))
    colnames(counts_exon) <-
      gsub(pattern, "", colnames(counts_exon))
    colnames(counts_intron) <-
      gsub(pattern, "", colnames(counts_intron))

  } else {
    counts_exon <-
      Countsmerge(
        filepath = filepath,
        pattern = pattern[1],
        SampleInfo = SampleInfo,
        ColName = ColName
      )
    counts_intron <-
      Countsmerge(
        filepath = filepath,
        pattern = pattern[2],
        SampleInfo = SampleInfo,
        ColName = ColName
      )
    seq_info <- data.frame()
  }


  ## make S4 object
  results <-
    EIquantifylist(
      counts_exon = counts_exon,
      counts_intron = counts_intron,
      SampleInfo = SampleInfo,
      seq_info = seq_info
    )

  return(results)
}
